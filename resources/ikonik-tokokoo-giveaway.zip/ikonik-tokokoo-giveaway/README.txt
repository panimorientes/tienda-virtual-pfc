====================================================
WWW.TOKOKOO.COM 
====================================================

�iKonik� is a free theme Layout release and we thus release it �as is�. We Tokokoo.com will not be offering any support to users of this theme layout. 

By downloading this layout, under the terms of the GNU General Public License, it is vital that you understood the following terms and conditions:

* You can use them on as many domain names as you wish.

* You may use them for your clients� projects / websites. Number of projects is not limited.

* You may not claim intellectual and exclusive ownership to any of the layout.

* You may not sub-license the original layout and their individual files to and with anyone else, unless a specific license within the layout states otherwise.

* You may modify them. However, you may not modify and then resell, unless the modified versions are drastically different from the originals.
We reserve the right to refuse, cancel, or suspend service at our sole discretion and the right to change or modify these terms with no prior notice.

* No support will be provided for any free theme/layout Tokokoo.

* Do not provide the direct download link nor upload �iKonik� onto other servers for your own share (Please link to this article instead � we also deserve some traffic!). If you want to spread the words, just link to this article.

Don�t forget to  subscribe to our RSS-feed http://feeds.feedburner.com/tokokoo and  follow us on Twitter http://twitter.com/tokokoo � for recent updates.

give us your ticket list at http://www.tokokoo.com/support/ or support@tokokoo.com


Regards
Anggi Krisna
www.tokokoo.com
